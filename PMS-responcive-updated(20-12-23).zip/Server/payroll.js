const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const port = 3003;

mongoose.connect('mongodb://localhost:27017/payrollData', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});
const db = mongoose.connection;
db.on('error', console.error.bind(console, 'MongoDB connection error:'));
db.once('open', () => {
  console.log('Connected to MongoDB');
});

app.use(cors());
app.use(bodyParser.json());

const payrollSchema = new mongoose.Schema({
  department: String,
  designation: String,
  employee_name: String,
  year: String,
  month: String,
  houseRentAllowance: String,
  medicalAllowance: String,
  dearnessAllowance: String,
  travellingAllowance: String,
  pf: String,
  professional_tax: String,
  other_deductions: String,
  basicSalary: String,
  totalAllowances: String,
  totalDeductions: String,
  net_salary: String,
  pdfContent: String,
});

const Payroll = mongoose.model('Payroll', payrollSchema);

app.post('/payroll', async (req, res) => {
  try {
    const { pdfContent, ...payrollData } = req.body;

    const totalAllowances = (
      parseFloat(payrollData.houseRentAllowance) +
      parseFloat(payrollData.medicalAllowance) +
      parseFloat(payrollData.dearnessAllowance) +
      parseFloat(payrollData.travellingAllowance)
    ).toString();

    const netSalary = (
      parseFloat(payrollData.basicSalary) +
      parseFloat(totalAllowances) -
      parseFloat(payrollData.pf) -
      parseFloat(payrollData.professional_tax) -
      parseFloat(payrollData.other_deductions)
    ).toString();

    const newPayrollData = new Payroll({
      ...payrollData,
      pdfContent,
      totalAllowances,
      net_salary: netSalary,
      department: payrollData.department,

    });

    await newPayrollData.save();

    res.status(200).json({ message: 'Payroll data submitted successfully!' });
  } catch (error) {
    console.error('Error submitting payroll data:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
});

app.get('/downloadPayslip', async (req, res) => {
  try {
    const { designation, employee_name, year, month } = req.query;

    const payrollData = await Payroll.findOne({
      designation,
      employee_name,
      year,
      month,
    });

    if (!payrollData || !payrollData.pdfContent) {
      res.status(404).json({ message: 'Payslip not found' });
      return;
    }

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader(
      'Content-Disposition',
      `attachment; filename=payslip_${employee_name}_${month}_${year}.pdf`
    );
    res.send(Buffer.from(payrollData.pdfContent, 'base64'));
  } catch (error) {
    console.error('Error downloading payslip:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
});

app.get('/designationsAndEmployeeNames', async (req, res) => {
  try {
    const designations = await Payroll.distinct('designation');
    const employeeNames = await Payroll.distinct('employee_name');

    res.status(200).json({ designations, employeeNames });
  } catch (error) {
    console.error('Error fetching designations and employee names:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});