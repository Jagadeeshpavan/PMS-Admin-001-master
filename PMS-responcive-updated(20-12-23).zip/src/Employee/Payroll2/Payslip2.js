import React, { useState, useEffect } from 'react';
import './Payslip2.css';
import Sideba1 from "../Sideba1";

const DownloadPayslipPage = () => {
  const [designationsList, setDesignationsList] = useState([]);
  const [employeeNamesList, setEmployeeNamesList] = useState([]);
  const [designation, setDesignation] = useState('');
  const [employeeName, setEmployeeName] = useState('');
  const [year, setYear] = useState('');
  const [month, setMonth] = useState('');
  const [empId, setEmpId] = useState('');
  const [department, setDepartment] = useState('');

  useEffect(() => {
    const fetchDesignationsAndEmployeeNames = async () => {
      try {
        const response = await fetch('http://localhost:3003/designationsAndEmployeeNames');
        if (!response.ok) {
          throw new Error('Failed to fetch data');
        }
        const data = await response.json();
        setDesignationsList(data.designations);
        setEmployeeNamesList(data.employeeNames);
      } catch (error) {
        console.error('Error fetching data:', error);
        // Handle error
      }
    };
  
    fetchDesignationsAndEmployeeNames();
  }, []);
  

  const handleDownload = async () => {
    const formattedURL = `http://localhost:3003/downloadPayslip?designation=${encodeURIComponent(
      designation
    )}&employee_name=${encodeURIComponent(employeeName)}&year=${encodeURIComponent(
      year
    )}&month=${encodeURIComponent(month)}`;

    try {
      const response = await fetch(formattedURL, {
        method: 'GET',
      });

      if (!response.ok) {
        throw new Error('Failed to download payslip');
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `payslip_${employeeName}_${month}_${year}.pdf`;
      document.body.appendChild(a);
      a.click();
      a.remove();
    } catch (error) {
      console.error('Error downloading payslip:', error.message);
      // Handle error (e.g., show error message)
    }
  };

  return (
    <div className='main890'>
       <Sideba1 />
       <div className='flexchange112'>
      <div className='cont'>
        <h1 className='heading453' >Download Payslip</h1>
        <div className='label-container45'>
        <label className='label564'>
          EmpId:
           </label>
          <input type="text" className='indomodh789' value={empId} onChange={(e) => setEmpId(e.target.value)} />
          </div>
         
          <div className='label-container45'>
        <label  className='label564'>
          Department:
          </label>
          <input type="text" className='indomodh789' value={department} onChange={(e) => setDepartment(e.target.value)} />
          </div>
          <div className='label-container45'>
        <label  className='label564'>
          Designation:
          </label>
          <select
            value={designation}
            className='indomodh'
            onChange={(e) => setDesignation(e.target.value)}
          >
           {/* Example */}
<option value="">Select Designation</option>
<option value="FullStack">Full Stack</option>
<option value="AppDevelopment">App Development</option>
{/* ... */}

            {designationsList.map((desig, index) => (
              <option key={index} value={desig}>
                {desig}
              </option>
            ))}
          </select>
          </div>
        
          <div className='label-container45'>
        <label  className='label564'>
          Employee Name:&nbsp;
          </label>
          <select
            value={employeeName}
            className='indomodh'
            onChange={(e) => setEmployeeName(e.target.value)}
          >
            <option value="">Select Employee Name</option>
            <option value="PARASHURAM">PARASHURAM</option>
            <option value="DAMODAR">DAMODAR</option>
            {employeeNamesList.map((emp, index) => (
              <option key={index} value={emp}>
                {emp}
              </option>
            ))}
          </select>
          </div>
        
          <div className='label-container45'>
        <label  className='label564'>
          Month:
          </label>
          <select
            value={month}
            className='indomodh'
            onChange={(e) => setMonth(e.target.value)}
          >
            <option value="">Select Month</option>
            <option value="January">January</option>
            <option value="February">February</option>
            <option value="March">March</option>
            <option value="April">April</option>
            <option value="May">May</option>
            <option value="June">June</option>
            <option value="July">July</option>
            <option value="August">August</option>
            <option value="September">September</option>
            <option value="October">October</option>
            <option value="November">November</option>
            <option value="December">December</option>
          </select>
          </div>
       
          <div className='label-container45'>
        <label  className='label564'>
          Year:
          </label>
          <select
            value={year}
            className='indomodh'
            onChange={(e) => setYear(e.target.value)}
          >
            <option value="">Select Year</option>
            {Array.from({ length: 10 }, (_, index) => {
              const currentYear = new Date().getFullYear();
              const yearValue = currentYear - index;
              return (
                <option key={yearValue} value={yearValue}>
                  {yearValue}
                </option>
              );
            })}
          </select>
          </div>

          <div className='center-btn543'>
        <button onClick={handleDownload} className="downloadButton">
          Download Payslip
        </button>
        </div>
      </div>
      </div>
    </div>
  );
};

export default DownloadPayslipPage;