import React, { useState } from "react";

// import "./Leaave.css";
import "./Leave2.css"
import Sideba1 from "../Sideba1";
import { Sidebarda1 } from "../Sidebarda1";
import SidebarMenu from "../SidebarMenu";
import SideBar2 from "../SideBar2";

const Leave2 = () => {
  const [status, setStatus] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setStatus("Sending...");
    const { empId, empName, empDepartment, leaveType, fromDate, toDate, comment, file } = e.target.elements;
    let details = {
      empId: empId.value,
      empName: empName.value,
      empDepartment: empDepartment.value,
      leaveType: leaveType.value,
      fromDate: fromDate.value,
      toDate: toDate.value,
      comment: comment.value,
      file: file.value,
    };
    const response = await fetch("http://localhost:5001/Leave", {
      method: "POST",
      headers: {
        "Content-Type": "application/json;charset=utf-8",
      },
      body: JSON.stringify(details),
    });
    setStatus("");
    const result = await response.json();
    alert(result.status);
  };
  return (
    <>
      <Sideba1 />

      <div className="custom-container">

        <div className="custom-sec-page">
          <div className="custom-daily">
            <h1 className="custom-leavetypeh1">Apply Leave</h1>
          </div>
          <form
            action="/contact"
            method="POST"
            encType="multipart/form-data"
            onSubmit={handleSubmit}
          >
            <div className="custom-leavetype">
              <label className="custom-employee-label" htmlFor="empId">
                Emp ID
              </label>
              <input
                type="text"
                id="custom-empId"
                name="empId"
                className="custom-sasi"
                required
              />
            </div>
            <div className="custom-leavetype">
              <label className="custom-employee-label" htmlFor="empName">
                Emp Name
              </label>
              <input
                type="text"
                id="custom-empName"
                name="empName"
                className="custom-sasi"
                required
              />
            </div>
            <div className="custom-leavetype">
              <label className="custom-employee-label" htmlFor="empDepartment">
                Emp Department
              </label>
              <input
                type="text"
                id="custom-empDepartment"
                name="empDepartment"
                className="custom-sasi"
                required
              />
            </div>

            <div className="custom-leavetype">
              <label className="custom-employee-label" htmlFor="leaveType">
                Leave Type
              </label>
              <select
                id="custom-leaveType"
                name="leaveType"
                className="custom-sasi"
                required
              >
                <option value="">Select Leave Type</option>
                <option value="Annual Leave">Annual Leave</option>
                <option value="Sick Leave">Sick Leave</option>
                <option value="Maternity/Paternity Leave">
                  Maternity/Paternity Leave
                </option>
                <option value="Personal Leave">Personal Leave</option>
                <option value="Other">Other</option>
              </select>
            </div>
          
          <div className="flex342">
            <div className="custom-from">
              <label className="custom-employee-label" htmlFor="fromDate">
                From
              </label>
              <input
                className="custom-date"
                type="date"
                id="custom-fromDate"
                name="fromDate"
                required
              />
            </div>

            <div className="custom-from">
              <label className="custom-employee-label" htmlFor="toDate">
                To
              </label>
              <input
                className="custom-date"
                type="date"
                id="custom-toDate"
                name="toDate"
                required
              />
            </div>
            </div>
            <div className="custom-leavetype">
              <label className="custom-employee-label" htmlFor="comment">
                Purpose of leave
              </label>
              <textarea id="custom-comment" name="comment" required></textarea>
            </div>

            <div className="custom-leavetype">
              <label className="custom-employee-label" htmlFor="profilePhoto">
                Upload Document
              </label>
              <input className="custom-file" type="file" id="custom-file" name="file" />
            </div>

            <div className="center342">
              <button className="custom-leave-button" type="submit">
                {status}
                Save
              </button>
            </div>
          </form>
        </div>
      </div>
    </>
  );
};

export default Leave2;