import React, { useState, useEffect } from 'react';
import Clock from 'react-clock';
import 'react-clock/dist/Clock.css';
import './DigitalClock.css'; // Create a separate CSS file for styling
import Sideba1 from "../Sideba1";
import Calender from '../Calender';

const DigitalClock = () => {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [enteredId, setEnteredId] = useState('');
  const [isDayStarted, setIsDayStarted] = useState(false);
  const [currentDate, setCurrentDate] = useState('');
  const [startOfWorkday, setStartOfWorkday] = useState(null);
  const [endOfWorkday, setEndOfWorkday] = useState(null);
  const [showSeeYouMessage, setShowSeeYouMessage] = useState(false);

  useEffect(() => {
    const intervalId = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(intervalId);
  }, []);

  const handleStartOfWorkday = () => {
    setStartOfWorkday(new Date());
    setIsDayStarted(true);
    setCurrentDate(new Date().toLocaleString());
    sendTimeDataToBackend('start');
  };

  const handleEndOfWorkday = () => {
    setEndOfWorkday(new Date());
    setIsDayStarted(false);
    setCurrentDate(new Date().toLocaleString());
    sendTimeDataToBackend('end');
    setShowSeeYouMessage(true);
    setTimeout(() => {
      setShowSeeYouMessage(false);
      window.location.reload();
    }, 3000);
  };

  const handleEnteredIdChange = (e) => {
    setEnteredId(e.target.value);
  };

  const sendTimeDataToBackend = (status) => {
    if (!enteredId) {
      alert('Please enter your ID number.');
      return;
    }

    const timeData = {
      employeeId: enteredId,
      status: status,
      timestamp: new Date(), // Use the current date and time
    };

    fetch('http://localhost:5000/Employee', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(timeData),
    })
      .then(response => {
        if (!response.ok) {
          throw new Error('Network response was not ok.');
        }
        return response.json();
      })
      .then(data => {
        console.log('Data sent successfully:', data);
      })
      .catch(error => {
        console.error('There was an error sending data to the server:', error);
      });
  };

  return (
    <>
    
      <Sideba1 />
<div className='masterc-container123'>
      <div>
      <div className="digital-clock-container">
      <Clock value={currentTime} renderNumbers={true} hourMarksLength={20} minuteMarksLength={10}/>

      {/* Input field for entering ID */}
      
        <div className='flex23'>
          <div>
        <label htmlFor="employeeId" className="enter-id">Enter Employee ID </label>
        <input 
          type="text"
          id="employeeId"
          className='input_field'
          value={enteredId}
          onChange={handleEnteredIdChange}
          placeholder="Enter ID"
        />
</div>
<div >  
          {!isDayStarted ? ( 
            <button className="workday-buttons start-day" onClick={handleStartOfWorkday}> Start Workday </button>
          ) : (
            <button className="workday-buttons end-day" onClick={handleEndOfWorkday}>End Workday</button>
          )}
        </div> 
        </div>

        {/* Buttons to mark start and end of the workday */}
       

        {/* Display timestamps and ID */}
        {(startOfWorkday || endOfWorkday) && (
          <p className='daystart'> 
            {isDayStarted ? 'Start of Workday' : 'End of Workday'}: {currentDate}
          </p>
        )}
        {enteredId && (
           <p className='p_enteredid'> Entered ID: {enteredId}</p>
        )}

        {/* Pop-up message */}
        {showSeeYouMessage && (
          <div className="popup">
            <p>Your day is end...!  See you tomorrow!</p>
          </div>
        )}
      

      <marquee class="dark-blue-text" behavior="scroll" direction="left" scrollamount="6">
        Punctuality matters! Arrive on time and punch in promptly to start your day
    </marquee>
  
    </div>
    </div>
      <div><Calender/></div>
      </div>
      </>
  );
};

export default DigitalClock;
