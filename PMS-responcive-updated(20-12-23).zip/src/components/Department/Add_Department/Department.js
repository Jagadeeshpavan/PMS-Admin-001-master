import React from 'react';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import axios from 'axios';
import './Department.css'
import Sidebar from '../../Sidebar';


const Department = () => {
  const initialValues = {
    departmentid: '',
    departmentname: '',
    description: '',
    designation: '',
    departmenthead: '',
  };

  const validationSchema = Yup.object().shape({
    departmentid: Yup.string().required('departmentid is required'),
    departmentname: Yup.string().required('departmentname is required'),
    description: Yup.string().required('description is required'),
    designation: Yup.string().required('designation is required'),
    departmenthead: Yup.string().required('departmenthead is required'),
  });

  const handleSubmit = async (values, { setSubmitting, resetForm }) => {
    try {
      setSubmitting(true);
      await axios.post('http://localhost:3003/department_data/add', values);
      alert('Form submitted successfully');
      resetForm();
    } catch (error) {
      console.error(error);
      alert('Error submitting form');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className='home1s'>
      <Sidebar/>
    <div className="outsideborderr1s">
      <div className="employee-form-container1s">
        <h2 className="form-title1s">Add Department</h2>
        {/* <hr className='hr-tag-saaasisi'/> */}
        <Formik
          initialValues={initialValues}
          validationSchema={validationSchema}
          onSubmit={handleSubmit}
        >
          {({ isSubmitting }) => (
            <Form className='sandeep1s'>

              <div className="employee-group1s">
                <label  className="employee-label1s" htmlFor="departmentid">Department Id:</label>
                <Field type="text" id="departmentid" name="departmentid"  className="employee-fields1s"/>
                <ErrorMessage name="departmentid" component="div" className="error-message1s" />
              </div>

              <div className="employee-group1s">
                <label  className="employee-label1s" htmlFor="departmentname">Department Name: </label>
                <Field type="text" id="departmentname" name="departmentname" className="employee-fields1s" />
                <ErrorMessage name="departmentname" component="div" className="error-message1s" />
              </div>

              <div className="employee-group1s">
                <label  className="employee-label1s" htmlFor="description">Description: </label>
                <textarea type="text" id="description" name="description"  className="employee-fields1s"/>
                <ErrorMessage name="description" component="div" className="error-message1s" />
              </div>

              <div className="employee-group1s">
                <label  className="employee-label1s" htmlFor="designation">Designation:</label>
                <Field type="text" id="designation" name="designation" className="employee-fields1s" />
                <ErrorMessage name="designation" component="div" className="error-message1s" />
              </div>

              <div className="employee-group1s">
                <label  className="employee-label1s" htmlFor="departmenthead">Department Head:</label>
                <Field type="text" id="departmenthead" name="departmenthead" className="employee-fields1s" />
                <ErrorMessage name="departmenthead" component="div" className="error-message1s" />
              </div>
              <div className="employee-btngroup">
                <button className="employee-button1s" type="submit" disabled={isSubmitting} data-aos="fade-up">
                  {isSubmitting ? 'Submitting...' : 'Submit'}
                </button>
              </div>
            </Form>
          )}
        </Formik>
      </div>
    </div>
    </div>
  );
};

export default Department;