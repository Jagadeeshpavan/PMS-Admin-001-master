import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './ManageDepartment.css';
import Sidebar from '../../Sidebar';

const ManageDepartment = () => {
    const [departmentList, setDepartmentList] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    useEffect(() => {
        fetchDepartmentData();
    }, []);

    const fetchDepartmentData = () => {
        setLoading(true);
        setError(null);

        axios
            .get('http://localhost:3003/department_data')
            .then(response => {
                const fetchedData = response.data;
                const dataWithDepId = fetchedData.map(department => ({
                    departmentid: department.departmentid,
                    departmentname: department.departmentname,
                    description: department.description,
                    designation: department.designation,
                    departmenthead: department.departmenthead,
                    isSelected: false, // Add isSelected field
                }));

                setDepartmentList(dataWithDepId);
                setLoading(false);
            })
            .catch(error => {
                setError(error.message);
                setLoading(false);
            });
    };

    const handleDepartmentNameChange = (event, index) => {
        const updatedList = [...departmentList];
        updatedList[index].departmentname = event.target.value;
        setDepartmentList(updatedList);
    };

    const handleDescriptionChange = (event, index) => {
        const updatedList = [...departmentList];
        updatedList[index].description = event.target.value;
        setDepartmentList(updatedList);
    };

    const handleDesignationChange = (event, index) => {
        const updatedList = [...departmentList];
        updatedList[index].designation = event.target.value;
        setDepartmentList(updatedList);
    };

    const handleDepartmentHeadChange = (event, index) => {
        const updatedList = [...departmentList];
        updatedList[index].departmenthead = event.target.value;
        setDepartmentList(updatedList);
    };

    const handleCheckboxChange = (event, index) => {
        const updatedList = [...departmentList];
        updatedList[index].isSelected = !updatedList[index].isSelected;
        setDepartmentList(updatedList);
    };

    const handleDeleteClick = () => {
        const selectedRecords = departmentList.filter(department => department.isSelected);

        if (selectedRecords.length === 0) {
            alert('Please select at least one department to delete.');
            return;
        }

        const deletePromises = selectedRecords.map(record => {
            const url = `http://localhost:3003/department_data/${encodeURIComponent(record.departmentid)}`;
            return axios.delete(url);
        });

        Promise.all(deletePromises)
            .then(() => {
                const updatedList = departmentList.filter(department => !department.isSelected);
                setDepartmentList(updatedList);
                alert('Deleted Successfully');
            })
            .catch(error => {
                alert('Not Deleted Successfully', error);
            });
    };

    const handleUpdateClick = () => {
        const selectedRecords = departmentList.filter(department => department.isSelected);

        if (selectedRecords.length === 0) {
            alert('Please select at least one department to update.');
            return;
        }

        axios
            .put('http://localhost:3003/department_data', selectedRecords)
            .then(() => {
                alert('Updated Successfully');
            })
            .catch(error => {
                alert('Not Updated Successfully', error);
            });
    };

    return (
        <div className='home2s'>
            <Sidebar />
           
            <div className='class7856'>
            <div className='outsideborder2s'>
                <div className='daily2s'>
                    <h1 className='manage-employee2s'>Manage departments</h1>
                    {/* <h1 className='line2s'></h1>
                    <br /> */}

                    {loading ? (
                        <p className='loading90'>Loading...</p>
                    ) : error ? (
                        <p className='loading90'>Error: {error}</p>
                    ) : (
                        <div className='overflow254'>
                        <table className='department-table2s'>
                            <thead >
                                <tr>
                                   
                                    <th className='tableline34'>Department ID</th>
                                    <th className='tableline34'>Department Name</th>
                                    <th className='tableline34'>Description</th>
                                    <th className='tableline34'>Designation</th>
                                    <th className='tableline34'>Department Head</th>
                                    <th className='tableline34'>Select</th>
                                </tr>
                            </thead>
                            <tbody>
                                {departmentList.map((department, index) => (
                                    <tr key={department.departmentid}>
                                        <td>{department.departmentid}</td>
                                        <td className='tableline3489'>
                                            <input
                                                type='text'
                                                value={department.departmentname}
                                                onChange={event => handleDepartmentNameChange(event, index)}
                                            />
                                        </td>
                                        <td className='tableline3489'>
                                            <input
                                                type='text'
                                                value={department.description}
                                                onChange={event => handleDescriptionChange(event, index)}
                                            />
                                        </td>
                                        <td className='tableline3489'>
                                            <input
                                                type='text'
                                                value={department.designation}
                                                onChange={event => handleDesignationChange(event, index)}
                                            />
                                        </td>
                                        <td className='tableline3489'>
                                            <input
                                                type='text'
                                                value={department.departmenthead}
                                                onChange={event => handleDepartmentHeadChange(event, index)}
                                            />
                                        </td>
                                        <td className='tableline3489'>
                                            <input
                                                type='checkbox'
                                                checked={department.isSelected}
                                                onChange={event => handleCheckboxChange(event, index)}
                                            />
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                        </div>
                    )}
                </div>
                <div className='btnchange34'>
                <button className='manage-button2s' onClick={handleUpdateClick}>
                    Update
                </button>
                <button className='manage-button2s' onClick={handleDeleteClick}>
                    Delete
                </button>
                </div>
            </div>
            </div>
        </div>
    );
};

export default ManageDepartment;
