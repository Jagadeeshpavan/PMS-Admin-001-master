import React, { useState, useEffect } from "react";
import axios from "axios";
import Popup from "reactjs-popup";
import ManageEmployeeForm from "./ManageEmployeeForm";
import "./ManageEmployee.css";
import Sidebar from "../Sidebar";

const ManageEmployee = () => {
  const [employees, setEmployees] = useState([]);
  const [filteredEmployees, setFilteredEmployees] = useState([]);
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [isAddPopupOpen, setAddPopupOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [detailsModalOpen, setDetailsModalOpen] = useState(false);
  const [selectedEmployeeDetails, setSelectedEmployeeDetails] = useState(null);

  useEffect(() => {
    fetchEmployees();
  }, []);

  const fetchEmployees = async () => {
    try {
      const response = await axios.get("http://localhost:5001/employee_data");
      setEmployees(response.data);
      setFilteredEmployees(response.data);
    } catch (error) {
      console.error("Error fetching employees:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleViewDetails = (employee) => {
    const employeeDetails = employees.find(e => e.employeeid === employee.employeeid);
  
    if (employeeDetails) {
      setSelectedEmployeeDetails(employeeDetails);
      setDetailsModalOpen(true);
    } else {
      console.error("Employee details not found:", employee.employeeid);
    }
  };

  const handleEdit = (employee) => {
    setSelectedEmployee(employee);
    setAddPopupOpen(true);
  };

  const handleAddOrUpdate = async (formData) => {
    try {
      if (selectedEmployee) {
        await axios.put(
          `http://localhost:5001/employee_data/${selectedEmployee.employeeid}`,
          formData
        );
      } else {
        await axios.post("http://localhost:5001/employee_data/add", formData);
      }
      fetchEmployees();
      setSelectedEmployee(null);
      setAddPopupOpen(false);
    } catch (error) {
      console.error("Error adding/updating employee:", error);
      alert(
        "Error adding/updating employee. Please check the console for details."
      );
    }
  };

  const handleCancel = () => {
    setSelectedEmployee(null);
    setAddPopupOpen(false);
    setDetailsModalOpen(false);
  };

  const handleDelete = async (id) => {
    try {
      await axios.delete(`http://localhost:5001/employee_data/${id}`);
      fetchEmployees();
    } catch (error) {
      console.error("Error deleting employee:", error);
    }
  };

  const handleSearch = () => {
    const searchTermLowerCase = searchTerm.toLowerCase();
    const filtered = employees.filter(
      (employee) =>
        employee.employeeid.toLowerCase().includes(searchTermLowerCase) ||
        employee.fullname.toLowerCase().includes(searchTermLowerCase)
    );
    setFilteredEmployees(filtered);
  };

  return (
    <div className="toprange436">
      <Sidebar />
      <div className="centerchange12">
      <div className="employee-table-container">
        <h2 className="employee-heading">Employee Management</h2>
        <input
        className="search1"
          type="text"
          placeholder="Search by ID "
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
        <button className="search-button1" onClick={handleSearch}>
          Search
        </button>
        <div className="overchange34">
        <table className="employee-table">
          <thead className="thread45">
            <tr>
              <th>Employee ID</th>
              <th>Full Name</th>
              <th>Date of Birth</th>
              <th>Gender</th>
              <th>Phone</th>
              <th>Address</th>
              <th>Role</th>
              <th>Email</th>  
              <th>Actions</th>
            </tr>
          </thead>
          <tbody className="flowchain56">
            {filteredEmployees.map((employee) => (
              <tr key={employee.employeeid}>
                <td
                  className="clickable"
                  onClick={() => handleViewDetails(employee)}
                >
                  {employee.employeeid}
                </td>
                <td
                 
                >{employee.fullname}</td>
                <td
                  // className="clickable"
                  // onClick={() => handleViewDetails(employee)}
                >{employee.dateofbirth}</td>
                <td>{employee.gender}</td>
                <td
                  // className="clickable"
                  // onClick={() => handleViewDetails(employee)}
                >{employee.phone1}</td>
                <td>
                  {employee.address}
                </td>
                <td>
                  {employee.role}
                </td>
                <td
                  // className="clickable"
                  // onClick={() => handleViewDetails(employee)}
                >{employee.email}</td>
                
                <td className="M1">
                  <button
                    className="edit-button"
                    onClick={() => handleEdit(employee)}
                  >
                    Edit
                  </button>
                  <button
                    className="delete-button"
                    onClick={() => handleDelete(employee.employeeid)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        </div>
        {/* Employee Details Modal */}
        {detailsModalOpen && selectedEmployeeDetails && (
          <div className="pms-emp-pop">
            <div className="pms-emp-pop-content">
              <h2 className="pms-emp-pop1">Employee Details</h2>
              <p className="emp-id">Employee ID: {selectedEmployeeDetails.employeeid}</p>
              <p>Full Name: {selectedEmployeeDetails.fullname}</p>
              <p>Father's Name: {selectedEmployeeDetails.fathername}</p>
              <p>Gender: {selectedEmployeeDetails.gender}</p>
              <p>Date of Birth: {selectedEmployeeDetails.dateofbirth}</p>
              <p>Marital Status: {selectedEmployeeDetails.maritalstatus}</p>
              <p>Phone 1: {selectedEmployeeDetails.phone1}</p>
              <p>Phone 2: {selectedEmployeeDetails.phone2}</p>
              <p>Email: {selectedEmployeeDetails.email}</p>
              <p>Address: {selectedEmployeeDetails.address}</p>
              <p>Role: {selectedEmployeeDetails.role}</p>
              <p>Permanent Address: {selectedEmployeeDetails.permanentaddress}</p>
              <button onClick={handleCancel}>Close</button>
            </div>
          </div>
        )}

        <Popup
          open={selectedEmployee !== null || isAddPopupOpen}
          onClose={handleCancel}
          closeOnDocumentClick
        >
          <ManageEmployeeForm
            selectedEmployee={selectedEmployee}
            onSubmit={handleAddOrUpdate}
            onCancel={handleCancel}
          />
        </Popup>
      </div>
      </div>
    </div>
  );
};

export default ManageEmployee;
