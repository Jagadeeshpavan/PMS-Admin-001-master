import React, { useState, useEffect } from 'react';
// import '../styles/EmployeeForm.css';

const MangeEmployeeForm = ({ selectedEmployee, onSubmit, onCancel }) => {
  const [formData, setFormData] = useState({
    employeeid: '',
    fullname: '',
    fathername: '',
    gender: '',
    dateofbirth: '',
    maritalstatus: '',
    phone1: '',
    phone2: '',
    email: '',
    address: '',
    permanentaddress: '',
  });

  useEffect(() => {
    if (selectedEmployee) {
      setFormData(selectedEmployee);
    } else {
      setFormData({
        employeeid: '',
        fullname: '',
        fathername: '',
        gender: '',
        dateofbirth: '',
        maritalstatus: '',
        phone1: '',
        phone2: '',
        email: '',
        address: '',
        permanentaddress: '',
      });
    }
  }, [selectedEmployee]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({ ...prevData, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <div className="popup-overlay">
      <div className="popup-content1">
        <h2>{selectedEmployee ? 'Edit Employee' : 'Add Employee'}</h2>
        <form onSubmit={handleSubmit} className="popup-form">
          <div className="popup-input">
            <label>Employee ID:</label>
            <input
              type="text"
              name="employeeid"
              value={formData.employeeid}
              onChange={handleChange}
            />
          </div>
          <div className="popup-input">
            <label>Full Name:</label>
            <input
              type="text"
              name="fullname"
              value={formData.fullname}
              onChange={handleChange}
            />
          </div>
          <div className="popup-input">
            <label>Father Name:</label>
            <input
              type="text"
              name="fathername"
              value={formData.fathername}
              onChange={handleChange}
            />
          </div>

          <div className="popup-input">
            <label>Gender:</label>
            <select
              name="gender"
              value={formData.gender}
              onChange={handleChange}
            >
              <option value="male">Male</option>
              <option value="female">Female</option>
              <option value="other">Other</option>
            </select>
          </div>

          <div className="popup-input">
            <label>Date of Birth:</label>
            <input
              type="date"
              name="dateofbirth"
              value={formData.dateofbirth}
              onChange={handleChange}
            />
          </div>

          <div className="popup-input">
            <label>Marital Status:</label>
            <select
              name="maritalstatus"
              value={formData.maritalstatus}
              onChange={handleChange}
            >
              <option value="single">Single</option>
              <option value="married">Married</option>
            </select>
          </div>

          <div className="popup-input">
            <label>Phone 1:</label>
            <input
              type="tel"
              name="phone1"
              value={formData.phone1}
              onChange={handleChange}
            />
          </div>

          <div className="popup-input">
            <label>Phone 2:</label>
            <input
              type="tel"
              name="phone2"
              value={formData.phone2}
              onChange={handleChange}
            />
          </div>

          <div className="popup-input">
            <label>Email:</label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
            />
          </div>

          <div className="popup-input">
            <label>Address:</label>
            <textarea
              name="address"
              value={formData.address}
              onChange={handleChange}
            />
          </div>

          <div className="popup-input">
            <label>Permanent Address:</label>
            <textarea
    name="permanentaddress" 
    value={formData.permanentaddress}
    onChange={handleChange}
  />
          </div>
          
          <div className="button-group">
            <button className="popup-button" type="submit">
              {selectedEmployee ? 'Update' : 'Add'}
            </button>
            <button className="popup-button" type="button" onClick={onCancel}>
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default MangeEmployeeForm;