import React, { useState, useEffect } from 'react';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import axios from 'axios';
import './Employees.css';
import Sidebar from '../Sidebar';

const Employees = () => {
  const [selectedImage, setSelectedImage] = useState(null);
  const [displayImage, setDisplayImage] = useState(false);
  const [employeeId, setEmployeeId] = useState(null);
  const initialValues = {
    fullname: '',
    fathername: '',
    gender: '',
    dateofbirth: '',
    maritalstatus: '',
    phone1: '',
    phone2: '',
    email: '',
    password: '',
    confirmPassword: '',
    address: '',
    permanentaddress: '',
  };

  const validationSchema = Yup.object().shape({
    fullname: Yup.string().required('Full Name is required'),
    fathername: Yup.string().required('Father Name is required'),
    gender: Yup.string().required('Gender is required'),
    dateofbirth: Yup.string().required('Date of Birth is required'),
    maritalstatus: Yup.string().required('Marital Status is required'),
    phone1: Yup.string().required('Phone 1 is required'),
    phone2: Yup.string().required('Phone 2 is required'),
    email: Yup.string().email('Invalid email').required('Email is required'),
    password: Yup.string()
    .when('confirmPassword', (confirmPassword, schema) => {
      return confirmPassword
        ? schema.required('Password is required').min(8, 'Password must be at least 8 characters')
        : schema;
    }),

    confirmPassword: Yup.string()
      .oneOf([Yup.ref('password'), null], 'Passwords must match')
      .required('Confirm Password is required'),
    address: Yup.string().required('Your Address is required'),
    
  });

  const handleSubmit = async (values, { setSubmitting, resetForm }) => {
    try {
      setSubmitting(true);
      console.log(values);

      const formData = new FormData();
      Object.keys(values).forEach((key) => {
        formData.append(key, values[key]);
      });

      if (selectedImage) {
        formData.append('image', selectedImage);
      }

      const response = await axios.post('http://localhost:5001/employee_data/add', formData);

      if (response.status === 200) {
        alert('Form submitted successfully');
        setTimeout(() => {
          resetForm();
          setSelectedImage(null);
          setDisplayImage(false);
          setEmployeeId(response.data.employeeid);
        });
      } else {
        alert('Error submitting form');
      }
    } catch (error) {
      console.error('Form Submission Error:', error);
      alert('Error submitting form');
    } finally {
      setSubmitting(false);
    }
  };
  const handleImageChange = (e) => {
    const image = e.target.files[0];
    setSelectedImage(image);
    setDisplayImage(true);
  };

  const initialValue = '';
  const [latestEmployeeId, setLatestEmployeeId] = useState(initialValue);

  useEffect(() => {
    // Fetch the latest employee ID from the backend
    const fetchLatestEmployeeId = async () => {
      try {
        const response = await axios.get('http://localhost:5001/employee_data/latest_id');
        const latestId = response.data.latestId;

        // Extract the numeric part and increment
        const numericPart = parseInt(latestId.replace(/[^0-9]/g, ''), 10);
        const nextNumericPart = numericPart + 1;

        // Format the new employee ID
        const formattedNextId = `MTSD${nextNumericPart.toString().padStart(4, '0')}`;

        setLatestEmployeeId(formattedNextId);
      } catch (error) {
        console.error('Error fetching latest employee ID:', error);
      }
    };

    fetchLatestEmployeeId();
  }, []);

  return (
    <div className='Total'>
      <Sidebar />
      <div className='home01'>
        <br />
        <br />
       
       
        <div className="outsideborderr9999">
          <div className="employee-form-container000">
            <h2 className="form-title01">ADD EMPLOYEE</h2>
            {/* <div className="image-container2345">
              <div className="small-image1239">
                {displayImage && (
                  <img
                    src={selectedImage ? URL.createObjectURL(selectedImage) : 'img1_placeholder.jpg'}
                    className="IMG1230"
                    alt="Select"
                    onClick={() => document.querySelector("#imageInput").click()}
                    style={{ cursor: "pointer", marginBottom: "10px" }}
                  />
                )}
                <label className="button222" htmlFor="imageInput">
                  Select Image
                </label>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageChange}
                  style={{ display: "none" }}
                  id="imageInput"
                />
              </div>
            </div> */}
   

            <div className="image-container2345">
              <div className='flex124'>
              <div className="small-image1239">
                {displayImage && (
                  <img
                    src={selectedImage ? URL.createObjectURL(selectedImage) : 'img1_placeholder.jpg'}
                    className="IMG1230"
                    alt="Select"
                    onClick={() => document.querySelector("#imageInput").click()}
                    style={{ cursor: "pointer", marginBottom: "10px" }}
                  />
                )}
               
              </div>
              <label className="button222" htmlFor="imageInput">
                  Select Image
                </label>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageChange}
                  style={{ display: "none" }}
                  id="imageInput"
                />
              
                </div>
            </div>

            <div className='linechange2'>
            <Formik
              initialValues={initialValues}
              validationSchema={validationSchema}
              onSubmit={handleSubmit}
            >
              {({ isSubmitting }) => (
                

                <Form className='width657'>
                  <div className="employee-group98">
                    <div className='emp011'>
                      <label className="employee-label98" htmlFor="employeeid">Employee ID </label>
                      <div className="readonly-field">{latestEmployeeId}</div>
                    </div>
                  </div>

                  <div className="employee-group98">
                    <label className="employee-label98" htmlFor="fullName">Full Name</label>
                    <Field className="employee-fields98" type="employee-fields" id="fullname" name="fullname" />
                    <ErrorMessage name="fullname" component="div" className="error-message98" />
                  </div>

                  <div className="employee-group98">
                    <label className="employee-label98" htmlFor="fatherName">Father Name</label>
                    <Field className="employee-fields98" type="employee-fields" id="fathername" name="fathername" />
                    <ErrorMessage name="fathername" component="div" className="error-message98" />
                  </div>
                 
                  <div className="employee-group98">
                    <label className="employee-label9828">Gender</label>

                    <label className="employee-labels98">
                      <Field type="radio" name="gender" value="Male" className="field-with-margin1" />
                      Male
                    </label>
                    <label className="employee-labels98">
                      <Field type="radio" name="gender" value="Female" className="field-with-margin1" />
                      Female
                    </label>
                    <ErrorMessage name="gender" component="div" className="error-message98" />
                  </div>

                  <div className="employee-group98">
                    <label className="employee-label98">Date of Birth</label>
                    <Field className="employee-fields98" type="date" id="dateOfbirth" name="dateofbirth" />
                  </div>

                  <ErrorMessage name="dateofbirth" component="div" className="error-message98" />


                  <div className="employee-group98">
                    <label className="employee-label9828">Martial Status</label>

                    <label className="employee-labels98">
                      <Field type="radio" name="maritalstatus" value="Single" className="field-with-margin98" />
                      Single
                    </label>
                    <label className="employee-labels980">
                      <Field type="radio" name="maritalstatus" value="married" className="field-with-margin98" />
                      Married
                    </label>
                    <ErrorMessage name="maritalstatus" component="div" className="error-message98" />
                  </div>

                  <div className="employee-group98">
                    <label className="employee-label98" htmlFor="phone1">Phone No</label>
                    <Field className="employee-fields98" type="employee-fields" id="phone1" name="phone1" />
                    <ErrorMessage name="phone1" component="div" className="error-message98" />
                  </div>

                  <div className="employee-group98">
                    <label className="employee-label98" htmlFor="phone2">Phone - 2</label>
                    <Field className="employee-fields98" type="employee-fields" id="phone2" name="phone2" />
                    <ErrorMessage name="phone2" component="div" className="error-message98" />
                  </div>

                  <div className="employee-group98">
                    <label className="employee-label98" htmlFor="email">Email</label>
                    <Field className="employee-fields98" type="employee-email" id="email" name="email" />
                    <ErrorMessage name="email" component="div" className="error-message98" />
                  </div>

                  <div className="employee-group98">
                    <label className="employee-label98" htmlFor="password">Password</label>
                    <Field className="employee-fields98" type="password" id="password" name="password" />
                    <ErrorMessage name="password" component="div" className="error-message98" />
                  </div>

                  <div className="employee-group98">
                    <label className="employee-label98" htmlFor="confirmPassword">Confirm Password</label>
                    <Field className="employee-fields98" type="password" id="confirmPassword" name="confirmPassword" />
                    <ErrorMessage name="confirmPassword" component="div" className="error-message98" />
                  </div>




                  <div className="employee-group98">
                    <label className="employee-label98" htmlFor="localAddress">Local Address</label>
                    <Field className="employee-fields98" id="address" type="employee-fields" name="address" />
                    <ErrorMessage name="address" component="div" className="error-message98" />
                  </div>

                  <div className="employee-group98">
                    <label className="employee-label98" htmlFor="permanentAddress">Permanent Address</label>
                    {/* <textarea className="employee-fields98" type="employee-fields" id="permanentaddress" name="permanentaddress" /> */}
                    <Field className="employee-fields98" id="permanentaddress" type="employee-fields" name="permanentaddress" />
                   
                    <ErrorMessage name="permanentaddress" component="div" className="error-message98" />
                  </div>

                  <div className="employee-group988">
                    <button className="employee-button98" type="submit" disabled={isSubmitting} data-aos="fade-up">
                      {isSubmitting ? 'Submitting...' : 'Submit'}
                    </button>
                  </div>
                </Form>
              )}
            </Formik>
           
           
            </div>
          </div>
        </div>
        
      </div>
    </div>
  );
};

export default Employees;