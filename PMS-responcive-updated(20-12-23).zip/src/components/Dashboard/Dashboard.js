import React,{ useState, useEffect } from 'react';
import { BsFillBookmarkFill } from "react-icons/bs";
import { FaUsers } from "react-icons/fa";
import { FaTh, FaUser } from "react-icons/fa";
import './Dashboard.css'
import Sidebar from '../Sidebar';

const Dashboard = () => {
  const [employeeData, setEmployeeData] = useState([]);
  const [attendanceData, setAttendanceData] = useState([]);
  useEffect(() => {
    // Simulating data fetching from the database
    const fetchEmployeeData = async () => {
      try {
        // Perform API request or database query to fetch employee data
        // Replace the following code with your actual data fetching logic
        const response = await fetch('http://localhost:3003/employee_data');
        const data = await response.json();
console.log(response);
        // Update the employee data state
        setEmployeeData(data);
      } catch (error) {
        console.error('Error fetching employee data:', error);
      }
    };

    fetchEmployeeData();
  }, []);

  useEffect(() => {
    // Fetch attendance data
    const fetchAttendanceData = async () => {
      try {
        // Perform API request or database query to fetch attendance data
        const response = await fetch('http://localhost:3003/attendance_dashboard_data');
        const data = await response.json();

        // Update the attendance data state
        setAttendanceData(data);
      } catch (error) {
        console.error('Error fetching attendance data:', error);
      }
    };

    fetchAttendanceData();
  }, []);

  const totalDepartments = employeeData.length;
  const totalEmployees = employeeData.length;
  const totalPresentToday = attendanceData.filter(
    (attendance) => attendance.status === 'Present'
  ).length;
  const totalOnLeaveToday = attendanceData.filter(
    (attendance) => attendance.status === 'Absent'
  ).length;

  return (

    <div className='Home1p'>
      <Sidebar/>
      
    <div className='home1p'>
      <div className='outsideborder1p'>
        {/* <div className='daily1p'> */}
          <h1 className='manage-employee1p'>Dashboard</h1>
          {/* <h1 className='line1p'></h1> */}
          <div className='dashboard-header1p'>

            <div className='flexchain754'>
          <div className=" box645 box-bg-pink1p">
            {/* <div className='usha1ps'> */}
                    <p className='usha1p'>Total Employees</p>
                  
                    <div className="icon-value1p">
                      <div className="icon1p">
                      <FaUsers size={30}/>
                      
                      </div>
                      <span className="value456">  {totalEmployees}</span>
                     
                    </div>
                    {/* </div> */}
                  </div>
                  <div className="box645 box-bg-purple1p">
                  {/* <div className='usha1ps'> */}
                    <p className='usha1p'>Total Departments</p>                   
                    <div className="icon-value1p">
                      <div className="icon1p">
                      <FaTh size={30}/>
                      </div>
                     
                      <span className="value456"> {totalDepartments}</span>
                    </div>
                    </div>
                    {/* </div> */}
                  </div>
                  <div className='flexchain754'>
                  <div className="box645 box-bg-cyan1p">
                  {/* <div className='usha1ps'> */}
                    <p className='usha1p'>Present Today</p>
                  
                    <div className="icon-value1p">
                      <div className="icon1p">
                      <FaUser size={30}/>
                      </div>
                      
                      <span className="value456">  {totalPresentToday}</span>
                    </div>
                    {/* </div> */}
                  </div>

                  <div className="box645 box-bg-ash1p">
                  {/* <div className='usha1ps'> */}
                    <p className='usha1p'>On Leave Today</p>
                 
                    <div className="icon-value1p">
                      <div className="icon1p">
                      <BsFillBookmarkFill size={30}/>
                      </div>
                      
                      <span className="value456">   {totalOnLeaveToday}</span>
                    </div>
                    </div>
                  </div>
            {/* <div className='fields'>
              <h1 className='employee'>Total Departments</h1>
              {totalDepartments}
            </div>

            <div className='fields'>
              <h1 className='employee'>Total Employees</h1>
             {totalEmployees}
            </div>

            <div className='fields'>
              <h1 className='employee'>Total Present Today</h1>
              {totalPresentToday}
            </div>
            <div className='fields'>
              <h1 className='employee'>Total On Leave Today</h1>
              {totalOnLeaveToday}
            </div> */}

          </div>
        {/* </div> */}
      </div>

      <div className='outsideborder1p24'>
        {/* <div className='daily1p'> */}
          <h1 className='manage-employee11p' >Quote of the Day</h1>
          {/* <h1 className='line1p'></h1> */}
          <div className='header1p'>
            <div className='manage-employee11p23'style={{textDecoration:'none'}}>
              Opportunities dont happen, You create them
              -Chris
            </div>
          </div>
        {/* </div> */}
      </div>
    </div>
    </div>
  );
};

export default Dashboard;