import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import axios from 'axios';
import './LoginMern.css';

const LoginMern = () => {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    employeeid: '',
    password: '',
  });

  const [error, setError] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;

    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleRoleSelection = async (role) => {
    try {
      if (!role) {
        window.alert('Please select a role (Admin or Employee)');
        return;
      }
  
      const response = await axios.post('http://localhost:5001/login', {
        ...formData,
        role,
      });
  
      if (response.data.success) {
        window.alert('Login successful!');
  
        if (role === 'employee') {
          navigate('/Dashboard2'); // Redirect admin to AdminDashboard
        } else {
          navigate('/Dashboard2'); // Redirect employee to EmployeeDashboard
        }
      } else {
        setError(response.data.error);
      }
    } catch (err) {
      console.error('Error:', err.response.data);
  
      if (err.response.data.message) {
        window.alert(err.response.data.message);
      } else {
        window.alert('Check your EmployeeID or Password and role Selected are correct ');
      }
    }
  };
  

  return (
    <div className="login-body">
      <div className="login-container">
        <form className="login-form" onSubmit={(e) => e.preventDefault()}>
          <h1 className="login-title">LOGIN</h1>
          <div className="login-form-group">
            <label htmlFor="employeeid" className="login-label">
              Employee ID
            </label>
            <input
              type="text"
              id="employeeid"
              name="employeeid"
              value={formData.employeeid}
              onChange={handleChange}
              className="login-input"
              required
            />
          </div>

          <div className="login-form-group">
            <label htmlFor="password" className="login-label">
              Password
            </label>
            <input
              type="password"
              id="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              className="login-input"
              required
            />
          </div>

          {error && <p className="login-error">{error}</p>}

          <div className="role-buttons">
            <button
              className="role-button"
              onClick={() => handleRoleSelection('admin')}
            >
              Admin
            </button>

            <button
              className="role-button"
              onClick={() => handleRoleSelection('employee')}
            >
              Employee
            </button>
          </div>

          <p className="register-link">
            Don't have an account? <Link to="/RegistrationMern">Register</Link>
          </p>
          <p className="forgot-passoword-link">
            Forgot Password? <Link to="/ForgotPassword">Click Here</Link>
          </p>
        </form>
      </div>
    </div>
  );
};

export default LoginMern;
