import React, { useState, useRef } from "react";
import "./Payroll.css";
import jsPDF from 'jspdf';
import Sidebar from "../Sidebar";
import 'jspdf-autotable';
import axios from "axios";


const Payroll = () => {
  const [formData, setFormData] = useState({
    department: '',
    designation: '',
    employee_name: '',
    year: '',
    month: '',
    houseRentAllowance: '',
    medicalAllowance: '',
    dearnessAllowance: '',
    travellingAllowance: '',
    pf: '',
    professional_tax: '',
    other_deductions: '',
    basicSalary: '',
    totalAllowances: '0',
    totalDeductions: '0',
    net_salary: '',
    pdfContent: '',
  });
  const [submitting, setSubmitting] = useState(false);
  const [errors, setErrors] = useState({});
  const handleSubmit = async (e) => {
    e.preventDefault();
    const validationErrors = validateForm();
    if (Object.keys(validationErrors).length === 0) {
      try {
        // Include deductions data in formData
        const updatedFormData = {
          ...formData,
          deductions: deductions, // Assuming 'deductions' is the array containing deduction objects
        };

        const response = await axios.post('http://localhost:3003/payroll', formData);

        if (response.status === 200) {
          // Data successfully submitted to the backend
          // Perform any necessary actions on success
          console.log('Data submitted successfully');
        } else {
          // Handle error if the request was not successful
          console.error('Failed to submit data');
        }
      } catch (error) {
        // Handle network errors or other issues
        console.error('Error submitting data:', error);
      }
    } else {
      setErrors(validationErrors);
    }
  };
  const validateForm = () => {
    const validationErrors = {};



    return validationErrors;
  };

  const [department, setDepartment] = useState("");
  const [designation, setDesignation] = useState("");
  const [employee, setEmployee] = useState("");
  const [year, setYear] = useState("");
  const [month, setMonth] = useState("");
  const [allowances, setAllowances] = useState([]);
  const [newAllowance, setNewAllowance] = useState("");
  const [allowanceAmount, setAllowanceAmount] = useState("");
  const [deductions, setDeductions] = useState([]);
  const [newDeduction, setNewDeduction] = useState("");
  const [deductionAmount, setDeductionAmount] = useState("");
  const [basicSalary, setBasicSalary] = useState("");

  const handleDepartmentChange = (e) => {
    const selectedDepartment = e.target.value;
    setDepartment(selectedDepartment);
    // Clear designation and related data
    setDesignation('');
  }
  const [showAllowances, setShowAllowances] = useState(false);
  const [showDeductions, setShowDeductions] = useState(false);
  const [showSummary, setShowSummary] = useState(false);

  // const handleNext = () => {
  //   if (!showAllowances) {
  //     setShowAllowances(true);
  //   } else if (!showDeductions) {
  //     setShowDeductions(true);
  //   } else if (!showSummary) {
  //     setShowSummary(true);
  //   }
  // };

  const handleNext = () => {
    if (!showAllowances) {
      setShowAllowances(true);
    } else if (!showDeductions) {
      setShowDeductions(true);
    } else if (!showSummary) {
      setShowSummary(true);
    }
  };

  const handlePrevious = () => {
    if (showSummary) {
      setShowSummary(false);
    } else if (showDeductions) {
      setShowDeductions(false);
    } else if (showAllowances) {
      setShowAllowances(false);
    }
  };


  // const handleDesignationChange = (e) => {
  //   setDesignation(e.target.value);
  //   setEmployee("");
  // };
  const handleDesignationChange = (e) => {
    const selectedDesignation = e.target.value;
    setDesignation(selectedDesignation);
    setFormData({
      ...formData,
      designation: selectedDesignation,
      employee_name: '',
    });
  };

  // const handleEmployeeChange = (e) => {
  //   setEmployee(e.target.value);
  // };
  const handleEmployeeChange = (e) => {
    setEmployee(e.target.value);
    setFormData({
      ...formData,
      employee_name: e.target.value,
    });
  };
  const handleYearChange = (e) => {
    const selectedYear = e.target.value;
    setFormData({
      ...formData,
      year: selectedYear,
    });
  };

  const handleMonthChange = (e) => {
    const selectedMonth = e.target.value;
    setFormData({
      ...formData,
      month: selectedMonth,
    });
  };

  const handleAllowanceChange = (e) => {
    const selectedAllowance = e.target.value; // Get the selected allowance from the event
    setNewAllowance(selectedAllowance); // Update the newAllowance state
    setFormData({
      ...formData,
      newAllowance: selectedAllowance, // Update the newAllowance field in the formData object
    });
  };

  const handleAllowanceAmountChange = (e) => {
    setAllowanceAmount(e.target.value);
  };

  function handleViewPayslip() {
  }
  const handleAddAllowance = () => {
    const houseRent = parseFloat(formData.houseRentAllowance) || 0;
    const medical = parseFloat(formData.medicalAllowance) || 0;
    const dearness = parseFloat(formData.dearnessAllowance) || 0;
    const travel = parseFloat(formData.travellingAllowance) || 0;
    const basic = parseFloat(formData.basicSalary) || 0;
    const total = houseRent + medical + dearness + travel + basic;
    setFormData({ ...formData, totalAllowance: total });
  };

  const handleDeductionChange = (e) => {
    setNewDeduction(e.target.value);
  };

  const handleDeductionAmountChange = (e) => {
    setDeductionAmount(e.target.value);
  };

  const handleAddDeduction = () => {
    const pf = parseFloat(formData.pf) || 0;
    const professionalTax = parseFloat(formData.professional_tax) || 0;
    const otherDeductions = parseFloat(formData.other_deductions) || 0;

    const totalDeductions = pf + professionalTax + otherDeductions;
    setFormData({ ...formData, totalDeductions: totalDeductions });
  };


  const handleNextClick = () => {
    console.log("Next button clicked!");
  };

  // Function to calculate total allowances
  const calculateTotalAllowances = () => {
    let total = 0;
    allowances.forEach((allowance) => {
      total += parseFloat(allowance.amount);
    });
    return total.toFixed(2);
  };
  // Function to calculate total deductions
  const calculateTotalDeductions = () => {
    let total = 0;
    deductions.forEach((deduction) => {
      total += parseFloat(deduction.amount);
    });
    return total.toFixed(2);
  };
  // Function to calculate gross salary
  const calculateGrossSalary = () => {
    const totalAllowances = calculateTotalAllowances();
    const basic = parseFloat(formData.basicSalary || 0);
    const grossSalary = basic + parseFloat(totalAllowances);
    return grossSalary.toFixed(2);
  };
  //   const calculateNetSalary = () => {
  //     const basic = parseFloat(formData.basic_salary || 0);
  //     const totalAllowances = parseFloat(calculateTotalAllowances() || 0);
  //     const totalDeductions = parseFloat(calculateTotalDeductions() || 0);

  const calculateNetSalary = () => {
    const totalAllowances = parseFloat(formData.houseRentAllowance || 0) +
      parseFloat(formData.medicalAllowance || 0) +
      parseFloat(formData.dearnessAllowance || 0) +
      parseFloat(formData.travellingAllowance || 0);

    const totalDeductions = parseFloat(formData.pf || 0) +
      parseFloat(formData.professional_tax || 0) +
      parseFloat(formData.other_deductions || 0);

    const basicSalary = parseFloat(formData.basicSalary || 0);

    const netSalary = totalAllowances - totalDeductions + basicSalary;

    return netSalary;
  };
  const updateCalculatedValues = () => {
    const updatedFormData = {
      ...formData,
      houseRentAllowance: calculateTotalAllowances(),
      dearnessAllowance: calculateTotalDeductions(),
      travellingAllowance: formData.travellingAllowance,
      gross_Salary: calculateGrossSalary(),
      other_deductions: formData.other_deductions,
      basicSalary: formData.basicSalary,

      medicalAllowance: formData.medicalAllowance,
      totalAllowances: calculateTotalAllowances(),
      totalDeductions: calculateTotalDeductions(),
      net_salary: calculateNetSalary(),

    };
    setFormData(updatedFormData);
  };


  const generatePDF = async () => {
    const doc = new jsPDF();
    // Define xPos and other necessary variables
    const companyName = 'Matrical Technologies';
    const payslipText = 'Payslip';
    const fontSize = 20; // Adjust the font size if needed
    doc.setTextColor('#0000FF'); // Set color to red (change to your desired color)


    // Calculate the width of company name and Payslip text
    const companyNameWidth = doc.getStringUnitWidth(companyName) * fontSize / doc.internal.scaleFactor;
    const payslipWidth = doc.getStringUnitWidth(payslipText) * fontSize / doc.internal.scaleFactor;

    // Calculate the X position to center the texts
    const pageWidth = doc.internal.pageSize.width;
    const companyNameXPos = (pageWidth - companyNameWidth) / 2;
    const payslipXPos = (pageWidth - payslipWidth) / 2;

    // Positioning the texts at the top of the page
    const yPos = 15; // Adjust this value to position the text higher or lower

    doc.setFontSize(fontSize);
    doc.text(companyName, companyNameXPos, yPos); // Display Company Name
    doc.text(payslipText, payslipXPos, yPos + fontSize + 5); // Display Payslip text below the Company Name

    const logoImg = 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTW5UJ2xqIyL2UNkmjkp1I1RXP9zgmG2fi2yQ&usqp=CAU'; // Replace with your image URL

    // Image dimensions and positioning
    const logoWidth = 50; // Adjust the width of the logo as needed
    const logoHeight = 50; // Adjust the height of the logo as needed
    const logoXPos = 20; // X position of the logo
    const logoYPos = 20; // Y position of the logo

    // Load and add the company logo image
    doc.addImage(logoImg, 'jpeg', logoXPos, logoYPos, logoWidth, logoHeight);

    //
    const currentDate = new Date().toLocaleDateString();
    const currentTime = new Date().toLocaleTimeString();
    const dateTime = `Date: ${currentDate} | Time: ${currentTime}`;
    const dateTimeWidth = doc.getStringUnitWidth(dateTime) * fontSize / doc.internal.scaleFactor;
    const xPosDateTime = (pageWidth - dateTimeWidth) / 2;

    // Positioning the date and time at the bottom of the page
    const yPosDateTime = doc.internal.pageSize.height - 15; // Adjust this value to position the text higher or lower

    // Place the date and time at the calculated X and Y position
    doc.text(dateTime, xPosDateTime, yPosDateTime);



    // Calculate values
    const totalAllowances = parseFloat(formData.houseRentAllowance || 0) +
      parseFloat(formData.medicalAllowance || 0) +
      parseFloat(formData.dearnessAllowance || 0) +
      parseFloat(formData.travellingAllowance || 0);

    const totalDeductions = parseFloat(formData.pf || 0) +
      parseFloat(formData.professional_tax || 0) +
      parseFloat(formData.other_deductions || 0);

    // Your data for the PDF
    const data = [
      ['Department', department],
      ['Employee Name', employee],
      ['Designation', designation],
      ['Year', formData.year],
      ['Month', formData.month],
      ['House Rent Allowance', formData.houseRentAllowance],
      ['Dearness Allowance', formData.dearnessAllowance],
      ['Medical Allowance', formData.medicalAllowance],
      ['Travelling Allowance', formData.travellingAllowance],
      ['PF', formData.pf],
      ['Basic Salary', formData.basicSalary],
      ['Professional Tax', formData.professional_tax],
      ['Other Deductions', formData.other_deductions],
      ['Total Allowances', totalAllowances],
      ['Total Deductions', totalDeductions],
      ['Net Salary', totalAllowances - totalDeductions],
      // Add other data here in a similar manner
    ];

    // Headers for the table
    const headers = [['Particulars', 'Amount']];

    doc.autoTable({
      head: headers,
      body: data,
      startY: 18,
      didParseCell: function (data) {
        const rows = data.table.body;
        if (data.row.index === 0) {

          data.cell.styles.textColor = '#000000'; // Header text color
          data.cell.styles.lineWidth = 0.9; // Header border width
        } else {
          // Border for all other rows
          data.cell.styles.lineWidth = 0.5; // Border width for other rows
          data.cell.styles.lineColor = '#000000'; // Border color for other rows
        }
      }
    });
    // Add border around the entire page
    const pageCount = doc.internal.getNumberOfPages();
    for (let i = 1; i <= pageCount; i++) {
      doc.setPage(i);
      doc.setLineWidth(1); // Border width for the page
      doc.setDrawColor(0, 0, 255); // Blue color (RGB values)
      doc.rect(5, 5, doc.internal.pageSize.getWidth() - 10, doc.internal.pageSize.getHeight() - 10); // Adjust the border dimensions
    }

    // Save the generated PDF content as a data URI
    const pdfContent = doc.output('datauristring');

    // Update the formData state to include the generated pdfContent
    setFormData({ ...formData, pdfContent }); 

    // Call the function to save the PDF content to the database
    await savePDFToDatabase(pdfContent);

    doc.save('payslip.pdf');
  };

  const savePDFToDatabase = async (pdfContent) => {
    try {
      const dataToSend = {
        department: formData.department,
        designation: formData.designation,
        employee_name: formData.employee_name,
        year: formData.year,
        month: formData.month,
        houseRentAllowance: formData.houseRentAllowance,
        medicalAllowance: formData.medicalAllowance,
        dearnessAllowance: formData.dearnessAllowance,
        travellingAllowance: formData.travellingAllowance,
        pf: formData.pf,
        professional_tax: formData.professional_tax,
        other_deductions: formData.other_deductions,
        basicSalary: formData.basicSalary,
        totalAllowances: formData.totalAllowances,
        totalDeductions: formData.totalDeductions,
        net_salary: formData.net_salary,
        pdfContent: pdfContent, // Attach the PDF content
      };
  
      const response = await axios.post('http://localhost:3003/payroll', dataToSend);
      console.log('PDF saved to database:', response.data);
  
      // Modify the response to include pdfContent
      const responseDataWithPDF = { ...response.data, pdfContent: pdfContent };
      return responseDataWithPDF;
    } catch (error) {
      console.error('Error saving PDF to database:', error);
      throw error;
    }
  };

  const handleGeneratePDFAndSave = async () => {
    await generatePDF(); // Call the generatePDF function
    const pdfContent = formData.pdfContent; // Get the generated PDF content from state
    await savePDFToDatabase(pdfContent); // Call the savePDFToDatabase function with the PDF content
  };

  const generatePDFAndSaveToDatabase = async () => {
    const doc = new jsPDF();
    // Generate your PDF content
    const pdfContent = doc.output('datauristring');
  
    try {
      const responseData = await savePDFToDatabase(pdfContent);
      console.log('Response data with PDF content:', responseData);
      // Handle success or perform further actions with the responseData
    } catch (error) {
      console.error('Error occurred while generating and saving PDF:', error);
      // Handle error condition
    }
  };

  const handleMedicalAllowanceChange = (e) => {
    const value = e.target.value;
    setFormData({ ...formData, medicalAllowance: value });
  };
  const handleHouseRentAllowanceChange = (e) => {
    const value = e.target.value;
    setFormData({ ...formData, houseRentAllowance: value });
  };
  const handleTravellingAllowanceChange = (e) => {
    const value = e.target.value;
    setFormData({ ...formData, travellingAllowance: value });
  };
  // const handlePFChange = (e) => {
  const handlePFChange = (e) => {
    const value = e.target.value;
    setFormData({ ...formData, pf: value });
  };
  const handleProfessionalTaxChange = (e) => {
    const value = e.target.value;
    setFormData({ ...formData, professional_tax: value });
  };
  const handleOtherDeductionsChange = (e) => {
    const value = e.target.value;
    setFormData({ ...formData, other_deductions: value });
  };
  const handleBasicSalaryChange = (e) => {
    const basicSalaryValue = e.target.value;
    setFormData({
      ...formData,
      basic_salary: basicSalaryValue,
    });
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleDearnessAllowanceChange = (e) => {
    const value = e.target.value;
    setFormData({ ...formData, dearnessAllowance: value });
  };
  return (
    <div>
      <Sidebar />
      <div className='home1bal'>

        <div className='outsideborderbal'>
         
            <form className="formbal" onSubmit={handleSubmit}>
              <h1 className="heading342">CreatePayslip</h1>
              <div className="sectionbal">

                {!showAllowances && (
                  <div >

                    {/* <h2>Payslip:</h2> */}
                    <div className="form-groupbal">

                      <label className="departmentbal09" htmlFor="department">Department:</label><br></br>
                      <select
                        id="department"
                        className="form-control1"
                        value={department}
                        onChange={handleDepartmentChange}
                      >
                        <option value="">Select Department</option>
                        <option value="Fullstack Development">
                          Fullstack Development
                        </option>
                        <option value="Testing">Testing</option>
                        <option value="Data Analyst">Data Analyst</option>
                        <option value="Data Science">Data Science</option>
                        <option value="Digital Marketing">Digital Marketing</option>
                        <option value="Mechanical Engineering">
                          Mechanical Engineering
                        </option>
                      </select>
                    </div>

                    <div className="form-group1bal">
                      <label className="departmentbal09" htmlFor="designation">Designation:</label><br></br>
                      <select
                        id="designation"
                        className="form-control2bal"
                        value={formData.designation}
                        onChange={handleDesignationChange}
                        disabled={!department}
                      >
                        <option value="">Select Designation</option>
                        {department === "Fullstack Development" && (
                          <>
                            <option value="Fullstack Developer">
                              Fullstack Developer
                            </option>
                            <option value="Developer Lead">Developer Lead</option>
                            <option value="Developer Manager">Developer Manager</option>
                          </>
                        )}
                        {department === "Testing" && (
                          <>
                            <option value="Test Engineer">Test Engineer</option>
                            <option value="Test Lead">Test Lead</option>
                            <option value="Test Manager">Test Manager</option>
                          </>
                        )}
                        {department === "Data Analyst" && (
                          <option value="Data Analyst">Data Analyst</option>
                        )}
                        {department === "Data Science" && (
                          <option value="Data Scientist">Data Scientist</option>
                        )}
                        {department === "Digital Marketing" && (
                          <option value="Digital Marketing Executive">
                            Digital Marketing Executive
                          </option>
                        )}
                        {department === "Mechanical Engineering" && (
                          <option value="Design Engineer">Design Engineer</option>
                        )}
                      </select>
                    </div>

                    <div className="form-group2bal">
                      <label className="departmentbal09" htmlFor="employee">Employee:</label><br></br>
                      <select
                        id="employee"
                        className="form-control3bal"
                        value={formData.employee}
                        onChange={handleEmployeeChange}
                        disabled={!department || !designation}
                      >
                        <option value="">Select Employee</option>
                        {department === "Fullstack Development" &&
                          designation === "Fullstack Developer" && (
                            <>
                              <option value="SAHANA">SAHANA</option>
                              <option value="PARASHURAM">PARASHURAM</option>
                              <option value="DAMODAR">DAMODAR</option>
                              <option value="VIKAS">VIKAS</option>
                              <option value="BALARAM">BALARAM</option>
                              <option value="DEEPAK">DEEPAK</option>
                            </>
                          )}
                        {department === "Fullstack Development" &&
                          designation === "Developer Lead" && (
                            <>
                              <option value="ARUN">ARUN</option>
                              <option value="AMRUTH">AMRUTH</option>
                              <option value="NASEER">NASEER</option>

                            </>
                          )}
                        {department === "Fullstack Development" &&
                          designation === "Developer Manager" && (
                            <>
                              <option value="sandeep">sandeep</option>
                              <option value="revanth">revanth</option>
                              <option value="kiran">kiran</option>
                            </>
                          )}
                        {department === "Testing" && designation === "Test Engineer" && (
                          <>
                            <option value="devareddy">devareddy</option>
                            <option value="bhanu">bhanu</option>
                            <option value="mohan">mohan</option>
                            <option value="siva">siva</option>
                          </>
                        )}
                        {department === "Testing" && designation === "Test Lead" && (
                          <>
                            <option value="meena">meena</option>
                            <option value="suma">suma</option>
                            <option value="harika">harika</option>
                            <option value="MOUNI">MOUNI</option>
                          </>
                        )}
                        {department === "Testing" && designation === "Test Manager" && (
                          <>
                            <option value="HEMADRI">HEMADRI</option>
                            <option value="RAVINDRA">RAVINDRA</option>
                            <option value="PAVAN">PAVAN</option>
                            <option value="UDAY">UDAY</option>
                          </>
                        )}
                        {department === "Data Analyst" &&
                          designation === "Data Analyst" && (
                            <>
                              <option value="MAHESH">MAHESH</option>
                              <option value="NANI">NANI</option>
                              <option value="RAM">RAM</option>
                              <option value="NAGA">NAGA</option>
                            </>
                          )}
                        {department === "Data Science" &&
                          designation === "Data Scientist" && (
                            <>
                              <option value="RANA">RANA</option>
                              <option value="PAWAN">PAWAN</option>
                              <option value="LOKESH">LOKESH</option>
                              <option value="KARTHIK">KARTHIK</option>
                            </>
                          )}
                        {department === "Digital Marketing" &&
                          designation === "Digital Marketing Executive" && (
                            <>
                              <option value="VARUN">VARUN</option>
                              <option value="REDDY">REDDY</option>
                              <option value="NAIDU">NAIDU</option>
                              <option value="SANTHOSH">SANTHOSH</option>
                            </>
                          )}
                        {department === "Mechanical Engineer" &&
                          designation === "Design Engineer" && (
                            <>
                              <option value="RAHUL">RAHUL</option>
                              <option value="CHARAN">CHARAN</option>
                              <option value="SANJAY">SANJAY</option>
                              <option value="THARUN">THARUN</option>
                            </>
                          )}
                      </select>
                    </div>

                    <div className="form-group3bal">
                      <label className="departmentbal09" htmlFor="year">Year:</label><br></br>
                      <select
                        id="year"
                        className="form-control4bal"
                        value={formData.year}
                        onChange={handleYearChange}
                      >
                        <option value="">Select Year</option>
                        <option value="2021">2021</option>
                        <option value="2022">2022</option>
                        <option value="2023">2023</option>
                        <option value="2024">2024</option>
                      </select>
                    </div>

                    <div className="form-group4bal">
                      <label className="departmentbal09" htmlFor="month">Month:</label><br></br>
                      <select
                        id="month"
                        className="form-control4bal"
                        value={formData.month}
                        onChange={handleMonthChange}
                      >
                        <option value="">Select Month</option>
                        <option value="January">January</option>
                        <option value="February">February</option>
                        <option value="March">March</option>
                        <option value="April">April</option>
                        <option value="May">May</option>
                        <option value="June">June</option>
                        <option value="July">July</option>
                        <option value="August">August</option>
                        <option value="September">September</option>
                        <option value="October">October</option>
                        <option value="November">November</option>
                        <option value="December">December</option>
                      </select>
                    </div>

                    {/* <button className="btn-btn-primary1bal" onClick={handleNextClick}>Submit </button> */}
                    <button className="next1btn" onClick={handleNext}>Next </button>


                  </div>
                )}
              </div>

              <div className="sectionbal">
                {showAllowances && !showDeductions && (
                  <div className="formbal">
                    <h2>Allowances</h2>
                    <div className="form-groupbal">


                      <label htmlFor="medical">House rent Allowance:</label>
                      <input

                        type="text"
                        id="houseRentAllowance"
                        name="houseRentAllowance"
                        value={formData.house_rent_allowance}
                        onChange={handleHouseRentAllowanceChange}
                      />
                      <div className="form-groupbal">
                        <label htmlFor="medical">Medical Allowance:</label>
                        <input
                          type="text"
                          id="medical"
                          name="medical"
                          value={formData.medical_allowance}
                          onChange={handleMedicalAllowanceChange}
                        />
                      </div>
                      <div className="form-groupbal">
                        <label htmlFor="dearness">Dearness Allowance:</label>
                        <input
                          type="text"
                          id="dearness"
                          name="dearness"
                          value={formData.dearness_allowance}
                          onChange={handleDearnessAllowanceChange}
                        />
                      </div>
                      {/* Add similar input fields for other allowances */}

                      {/* Additional fields for other deductions, salary, etc. */}
                      <div className="form-groupbal">
                        <label htmlFor="travel">Travelling Allowance:</label>
                        <input
                          type="text"
                          id="travel"
                          name="travel"
                          value={formData.travelling_allowance}
                          onChange={handleTravellingAllowanceChange}
                        />
                      </div>
                      <div className="form-groupbal">
                        <label htmlFor="basicSalary">Basic Salary:</label>
                        <input
                          type="text"
                          id="basicSalary"
                          name="basicSalary"
                          value={formData.basicSalary}

                          onChange={(e) => setFormData({ ...formData, basicSalary: e.target.value })}
                        />
                      </div>
                    </div>



                    <button className="btn btn-primarybal" onClick={handleAddAllowance}>
                      Add
                    </button>
                    <div className="form-groupbal">
                      <label>Total Allowance:</label>
                      <input
                        type="text"
                        id="totalAllowance"
                        name="totalAllowance"
                        value={formData.totalAllowance || ''} // Ensure it's a string or empty string
                        readOnly
                      />
                    </div>
                    <div className="pre">
                    <button className="" onClick={handlePrevious}>Previous</button>
                     <button className="pre1" onClick={handleNext}>Next</button>
                    </div>
                    {allowances.length > 0 && (
                      <div className="allowancesbal">
                        <h3>Added Allowances:</h3>
                        <ul>
                          {allowances.map((allowance, index) => (
                            <li key={index}>
                              {allowance.name} - {allowance.amount}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>)}
              </div>

              <div className="sectionbal">

                {showDeductions && !showSummary && (
                  <div className="formbal">
                    <h2>Deductions:</h2>

                    <div className="form-rowbal">
                      <div className="form-groupbal">
                        {/* <label htmlFor="deductions">Deductions:&nbsp;</label> */}
                        <div className="form-groupbal">
                          <label htmlFor="pf">Provident fund:</label>
                          <input
                            type="text"
                            id="pf"
                            name="pf"
                            value={formData.pf}
                            onChange={handlePFChange}
                          />
                        </div>

                        {/* Input field for Professional Tax */}
                        <div className="form-groupbal">
                          <label htmlFor="professionalTax">Professional Tax:</label>
                          <input
                            type="text"
                            id="professionalTax"
                            name="professionalTax"
                            value={formData.professional_tax}
                            onChange={handleProfessionalTaxChange}
                          />
                        </div>

                        {/* Input field for Other Deductions */}
                        <div className="form-groupbal">
                          <label htmlFor="otherDeductions">Other Deductions:</label>
                          <input
                            type="text"
                            id="otherDeductions"
                            name="otherDeductions"
                            value={formData.other_deductions}
                            onChange={handleOtherDeductionsChange}
                          />
                        </div>

                      </div>


                      <button className="btn btn-primarybal" onClick={handleAddDeduction}>
                        Add Deduction
                      </button>
                      <div className="form-groupbal">
                        <label>Total Deductions:</label>
                        <input
                          type="text"
                          id="totalDeductions"
                          name="totalDeductions"
                          value={formData.totalDeductions || ''}
                          readOnly
                        />
                      </div>
                      {deductions.length > 0 && (
                        <div className="deductions">
                          <h3>Added Deductions:</h3>
                          <ul>
                            {deductions.map((deduction, index) => (
                              <li key={index}>
                                {deduction.name} - {deduction.amount}
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                    {/* <button  className="nextbal"onClick={handleNext}>Next...</button> */}
                    <button className="submit-button" onClick={handleGeneratePDFAndSave}>
                      Generate PDF
                    </button>
                  </div>)}
              </div>


              <div className="sectionbal">

                {showSummary && (
                  <div className="formbal">
                    <h2>Summary:</h2>
                    <div className="form-groupbal">
                      <label htmlFor="basicSalary">Basic:</label>
                      <div className="input-group">
                        <span className="input-group-textbal">&#8377;</span>
                        <input
                          type="text"
                          id="basicSalary"
                          className="form-controlbal"
                          value={formData.basicSalary}
                          onChange={(e) => setBasicSalary(e.target.value)}
                        />
                      </div>
                    </div>

                    <div className="form-groupbal">
                      <label>Total Allowances:</label>
                      <div className="input-groupbal">
                        <span className="input-group-text">&#8377;</span>
                        <input
                          type="text"
                          className="form-controlbal"
                          value={formData.calculateTotalAllowances()}
                          readOnly
                        />
                      </div>
                    </div>

                    <div className="form-groupbal">
                      <label>Gross Salary:</label>
                      <div className="input-groupbal">
                        <span className="input-group-textbal">&#8377;</span>
                        <input
                          type="text"
                          className="form-controlbal"
                          value={formData.calculateGrossSalary()}
                          readOnly
                        />
                      </div>
                    </div>

                    <div className="form-groupbal">
                      <label htmlFor="totalDeductions">Total Deductions:</label>
                      <div className="input-groupbal">
                        <span className="input-group-textbal">&#8377;</span>
                        <input
                          type="text"
                          className="form-controlbal"
                          value={formData.calculateTotalDeductions()}
                          readOnly
                        />
                      </div>
                    </div>

                    <div className="form-groupbal">
                      <label htmlFor="netSalary">Net Salary:</label>
                      <div className="input-groupbal">
                        <span className="input-group-textbal">&#8377;</span>
                        <input
                          type="text"
                          className="form-controlbal"
                          value={formData.calculateNetSalary()}
                          readOnly
                        />
                      </div>
                    </div>

                    <div className="form-groupbal">
                      <button type="submit" onClick={handleViewPayslip} className='A' class="btn  btn-block col-md-12 " disabled={submitting} data-aos="fade-up">
                        {submitting ? 'Submitting...' : 'Dashboard'}
                      </button>

                      {errors.serverError && <p className="text-danger">{errors.serverError}</p>}

                    </div>

                  </div>)}
              </div></form>

         
        </div>
      </div>
    </div>
  );
};

export default Payroll;