// import React, { useState } from "react";
// import styled from "styled-components";
// import { Link } from "react-router-dom";
// import * as FaIcons from "react-icons/fa";
// import * as AiIcons from "react-icons/ai";
// import { SidebarData } from "./SidebarData";
// import SubMenu from "./Submenu";
// import { IconContext } from "react-icons/lib";
// import { FaSun, FaMoon, FaUser } from "react-icons/fa";
// import "./Sidebar.css";

// const Nav = styled.div`
// background: rgb(0, 7, 61);
// position:fixed;
// width: 100%;
// color: white;
// height: 80px;
// display: flex;
// justify-content: space-between;
// align-items: center;
// transition: background 0.3s,color 0.3s;
// `;


// const NavIcon = styled(Link)`
//   margin-left: 2rem;
//   font-size: 2rem;
//   height: 45px;
//   display: flex;
//   justify-content: flex-start;
//   align-items: center;
//   color: ${({ isDarkMode }) => (isDarkMode ? "#fff" : "#000")};
// `;

// const ProfileIcon = styled.div`
//   font-size: 1.5rem;
//   margin-right: 20px;
//   cursor: pointer;
// `;

// const SidebarNav = styled.nav`
//   background: ${({ isDarkMode }) => (isDarkMode ? "#15171c" : "#ffffff")};
//   color: ${({ isDarkMode }) => (isDarkMode ? "#fff" : "#000")};
//   width: 250px;
//   height: 100vh;
//   display: flex;
//   justify-content: flex-start;
//   position: fixed;
//   top: 0;
//   left: ${({ sidebar }) => (sidebar ? "0" : "-250px")};
//   transition: left 350ms;
//   z-index: 10;
// `;

// const SidebarWrap = styled.div`
//   width: 100%;
//   overflow-y: auto;
//   background: ${({ isDarkMode }) => (isDarkMode ? "#15171c" : "rgb(0, 7, 61)")};
//   color: ${({ isDarkMode }) => (isDarkMode ? "#fff" : "#000")};
// `;

// const Sidebar = () => {
//   const [sidebar, setSidebar] = useState(true);
//   const [isDarkMode, setDarkMode] = useState(false);

//   const showSidebar = () => setSidebar(!sidebar);
//   const toggleDarkMode = () => setDarkMode(!isDarkMode);

//   return (
//     <>
//       <IconContext.Provider value={{ color: isDarkMode ? "#fff" : "white" }}>
//         <Nav isDarkMode={isDarkMode}>
//           <NavIcon to="#" isDarkMode={isDarkMode}>
//             <FaIcons.FaBars onClick={showSidebar} />
//           </NavIcon>
//           <h1>Matrical</h1>
//           <div className="mode"
//             style={{
//               display: "flex",
//               alignItems: "center",
//               marginRight: "20px",
//             }}
//           >
           
//             <span
//               style={{
//                 marginLeft: "10px",
//                 cursor: "pointer",
//               }}
//               onClick={toggleDarkMode}
//             >
//               {isDarkMode ? "" : ""}
//             </span>
           
//             { <ProfileIcon>
//               <FaUser />
//             </ProfileIcon> }
            

//           </div>
//         </Nav>
//         <SidebarNav sidebar={sidebar} isDarkMode={isDarkMode}>
//           <SidebarWrap>
//             <NavIcon to="#" isDarkMode={isDarkMode}>
//               <AiIcons.AiOutlineClose onClick={showSidebar} />
//             </NavIcon>
//             {SidebarData.map((item, index) => {
//               return <SubMenu item={item} key={index} />;
//             })}
//           </SidebarWrap>
//         </SidebarNav>
//       </IconContext.Provider>
//     </>
//   );
// };

// export default Sidebar;


import React, { useState } from "react";
import styled from "styled-components";
import { useNavigate } from 'react-router-dom';
import { Link } from "react-router-dom";
import * as FaIcons from "react-icons/fa";
import * as AiIcons from "react-icons/ai";
import { SidebarData } from "./SidebarData";
import Submen1 from "./Submenu";
import { IconContext } from "react-icons/lib";
import { FaSun, FaMoon, FaUser } from "react-icons/fa";
import "./Sidebar.css";



const Nav = styled.div`
background: rgb(0, 7, 61);
  position: fixed;
  margin-right: -365px;
  margin-bottom: 26%;
  width: 100%;
  color: #fff;
  height: 80px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  transition: background 0.3s, color 0.3s;
 box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
`;

const NavIcon = styled(Link)`
  margin-left: 2rem;
  font-size: 2rem;
  height: 80px;
  display: flex;
  justify-content: flex-start;
  align-items: center;
  color: #fff;
`;

const ProfileIcon = styled.div`
  font-size: 1.5rem;
  margin-right: 20px;
  cursor: pointer;
`;

const ProfileBox = styled.div`
  position: absolute;
  top: 57px;
  right: 1px;
  background: blue;
  width:max-content;
  block-size:max-content;
  color:white;
  padding: 10px;
  border-radius: 5px;
  display: ${({ showProfileBox }) => (showProfileBox ? "block" : "none")}
  
  

`;

const SidebarNav = styled.nav`
  background: rgb(0, 7, 61) ;
  color: #fff;
  width: 250px;
  height: 100vh;
  display: flex;
  justify-content: flex-start;
  margin-left:0px;
  position: fixed;
  top: fixed;
  left: ${({ sidebar }) => (sidebar ? "0" : "-247px")};
  transition: left 350ms;
  z-index: 10;
`;

const SidebarWrap = styled.div`
  width: 100%;
  overflow-y: auto;
  background: #15171c;
  color: #fff;
`;

const Sidebar = () => {
  const [sidebar, setSidebar] = useState(true);
  const [showProfileBox, setShowProfileBox] = useState(false);
  const navigate = useNavigate(); // Accessing the useNavigate hook

  const handleLogout = () => {
    // Perform logout logic if needed
    console.log("Logout ");

    // Redirect to the homepage
    navigate('/');
  };

  const showSidebar = () => setSidebar(!sidebar);

  const toggleProfileBox = () => {
    setShowProfileBox(!showProfileBox);
  };

  return (
    <>
      <IconContext.Provider value={{ color: "#fff" }}>
        <Nav>
          <NavIcon to="#">
            <FaIcons.FaBars onClick={showSidebar} style={{ color: "white" }} />
          </NavIcon>
          <h1 style={{ color: "white" }}>Matrical</h1>
          <div className="mode size65" style={{ position: "relative" }}>
            {/* Profile Icon */}
            <ProfileIcon onClick={toggleProfileBox}>
              <FaUser />
            </ProfileIcon>
            {/* Profile Box */}
            <ProfileBox showProfileBox={showProfileBox}>
              <p>Admin</p>
              <p>Email:Admin@Matrical.in</p>
              <p>Password:1234</p>
             
              {/* <button onClick={ handleLogout } style={{backgroundColor:"rgb(0, 7, 61)" , color:"white"}}>Logout</button> */}
              <button onClick={handleLogout}  className="customButton">
      Logout
    </button>
            </ProfileBox>
          </div>
        </Nav>
        <SidebarNav sidebar={sidebar}>
          <SidebarWrap>
            <NavIcon to="#">
              <AiIcons.AiOutlineClose onClick={showSidebar} />
            </NavIcon>
            {SidebarData.map((item, index) => {
              return <Submen1 item={item} key={index} />;
            })}
          </SidebarWrap>
        </SidebarNav>
      </IconContext.Provider>
    </>
  );
};

export default Sidebar;